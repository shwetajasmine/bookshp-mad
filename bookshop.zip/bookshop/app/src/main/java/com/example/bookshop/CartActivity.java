// CartActivity.java
package com.example.bookshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class CartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // Get book information from Intent
        String bookName = getIntent().getStringExtra("bookName");
        String price = getIntent().getStringExtra("price");
        String author = getIntent().getStringExtra("author");
        String edition = getIntent().getStringExtra("edition");

        // Display book information in TextViews
        TextView textViewBookName = findViewById(R.id.textViewBookName);
        textViewBookName.setText("Bookname: " + bookName);

        TextView textViewPrice = findViewById(R.id.textViewPrice);
        textViewPrice.setText("Price: " + price);

        TextView textViewAuthorEdition = findViewById(R.id.textViewAuthorEdition);
        textViewAuthorEdition.setText("Author: " + author + " , Edition: " + edition);

        // Place Order Button
        Button placeOrderButton = findViewById(R.id.placeOrderButton);
        placeOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle place order button click
                navigateToPaymentActivity(bookName, price);
            }
        });

        // Set up ActionBar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Your Cart");
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void navigateToPaymentActivity(String bookName, String price) {
        // Create an Intent to start PaymentActivity
        Intent intent = new Intent(this, PaymentActivity.class);
        // Pass both bookName and price as extras to the PaymentActivity
        intent.putExtra("bookName", bookName);
        intent.putExtra("totalAmount", price);
        startActivity(intent);
    }
}
