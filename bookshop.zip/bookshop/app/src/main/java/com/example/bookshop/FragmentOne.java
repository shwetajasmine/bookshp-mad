// FragmentOne.java
package com.example.bookshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class FragmentOne extends Fragment {

    public FragmentOne() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_one, container, false);

        // Get the TextView and set the text
        TextView textViewFragmentBest = view.findViewById(R.id.textViewFragmentBest);
        textViewFragmentBest.setText("Bookname: Programming with C");

        TextView textViewFragmentOne = view.findViewById(R.id.textViewFragmentOne);
        textViewFragmentOne.setText("Price: 1500Rs");

        TextView textViewFragmentNext = view.findViewById(R.id.textViewFragmentNext);
        textViewFragmentNext.setText("Author: John Hebrew , Edition: 5th edition");

        // Add a cart button
        Button addToCartButton = view.findViewById(R.id.addToCartButton);
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle cart button click
                addToCart();
            }
        });

        return view;
    }

    private void addToCart() {
        // Create an Intent to start the CartActivity
        Intent intent = new Intent(getActivity(), CartActivity.class);

        // Pass book information to CartActivity
        intent.putExtra("bookName", "Programming with C");
        intent.putExtra("price", "1500Rs");
        intent.putExtra("author", "John Hebrew");
        intent.putExtra("edition", "5th edition");

        // Start the CartActivity
        startActivity(intent);
    }
}
