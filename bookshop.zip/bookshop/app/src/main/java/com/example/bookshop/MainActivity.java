package com.example.bookshop;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.example.bookshop.DatabaseHelper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    EditText loginText, passwordText;
    Button btnLogin, btnGoToRegistration; // Added registration button
    TableLayout credentialsTable;

    // Declare DatabaseHelper
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Inside your activity's onCreate method
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("WELCOME TO ZIGBAY BOOKSHOP");

        loginText = findViewById(R.id.login);
        passwordText = findViewById(R.id.password);
        credentialsTable = findViewById(R.id.credentialsTable);

        btnLogin = findViewById(R.id.buttonLogin);
        btnGoToRegistration = findViewById(R.id.buttonGoToRegistration);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = loginText.getText().toString();
                String password = passwordText.getText().toString();


                boolean isValidCredentials = checkCredentials(username, password);

                if (isValidCredentials) {
                    Toast.makeText(MainActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, NewActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGoToRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegistrationActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean checkCredentials(String username, String password) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String[] columns = {DatabaseHelper.COLUMN_ID};
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ? AND " +
                DatabaseHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        // Query the database to check if credentials are valid
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);

        boolean isValid = cursor.getCount() > 0;

        // Close the cursor and database
        cursor.close();
        db.close();

        return isValid;
    }

    private void displayCredentialsInTable() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String[] columns = {DatabaseHelper.COLUMN_USERNAME, DatabaseHelper.COLUMN_PASSWORD};

        // Query the database to get all credentials
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns, null, null,
                null, null, null);

        // Clear the table before adding new data
        credentialsTable.removeAllViews();

        // Iterate through the cursor and add rows to the table
        while (cursor.moveToNext()) {
            String username = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_USERNAME));
            String password = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PASSWORD));

            // Create a new row
            TableRow row = new TableRow(this);

            // Create text views for username and password
            TextView usernameTextView = new TextView(this);
            usernameTextView.setText(username);

            TextView passwordTextView = new TextView(this);
            passwordTextView.setText(password);

            // Add text views to the row
            row.addView(usernameTextView);
            row.addView(passwordTextView);

            // Add the row to the table
            credentialsTable.addView(row);
        }

        // Close the cursor and database
        cursor.close();
        db.close();
    }
}
