// FragmentThree.java
package com.example.bookshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class FragmentThree extends Fragment {

    public FragmentThree() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_three, container, false);

        // Get the TextView and set the text
        TextView textViewOne = view.findViewById(R.id.textViewOne);
        textViewOne.setText("Bookname: Statement of Dewy Girl");

        TextView textViewTwo = view.findViewById(R.id.textViewTwo);
        textViewTwo.setText("Price: 350Rs");

        TextView textViewThree = view.findViewById(R.id.textViewThree);
        textViewThree.setText("Author: Dewy Macllin , Edition: 7th edition");

        // Add a cart button
        Button addToCartButton = view.findViewById(R.id.addToCartButton);
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle cart button click
                addToCart();
            }
        });

        return view;
    }

    private void addToCart() {
        // Create an Intent to start the CartActivity
        Intent intent = new Intent(getActivity(), CartActivity.class);

        // Pass book information to CartActivity
        intent.putExtra("bookName", "Statement of Dewy Girl");
        intent.putExtra("price", "350Rs");
        intent.putExtra("author", "Dewy Macllin");
        intent.putExtra("edition", "7th edition");

        // Start the CartActivity
        startActivity(intent);
    }
}
