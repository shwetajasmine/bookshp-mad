package com.example.bookshop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;



public class NewActivity extends AppCompatActivity {

    ImageView  buttonTopLeft;
    ImageView buttonTopRight;
    ImageView buttonBottomLeft;
    ImageView buttonBottomRight;
    ImageView buttonNext;
    ImageView buttonRepeat;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        ImageView buttonTopLeft = findViewById(R.id.button_topleft);
        ImageView buttonTopRight = findViewById(R.id.button_topright);
        ImageView buttonBottomLeft = findViewById(R.id.button_bottomleft);
        ImageView buttonBottomRight = findViewById(R.id.button_bottomright);
        ImageView buttonNext = findViewById(R.id.button_next);
        ImageView buttonRepeat = findViewById(R.id.button_repeat);

        buttonTopLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(NewActivity.this, "academic book section", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),academic.class);
                startActivity(intent);
            }
        });

        buttonTopRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(NewActivity.this, "fictional book section", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(),fictional.class);
                startActivity(intent);
            }
        });

        buttonBottomLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(NewActivity.this, "Historical book section", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(),historical.class);
                startActivity(intent);
            }
        });

        buttonBottomRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(NewActivity.this, "offers page", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(),offer.class);
                startActivity(intent);
            }
        });

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(NewActivity.this, "story book section", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(),story.class);
                startActivity(intent);
            }
        });

        buttonRepeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(NewActivity.this, " Non_fictional book section", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(),nonfictional.class);
                startActivity(intent);
            }
        });





    }
}