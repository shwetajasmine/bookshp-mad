// PaymentActivity.java
package com.example.bookshop;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class PaymentActivity extends AppCompatActivity {

    // Declare bookName as a class-level variable
    private String bookName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Set up ActionBar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Payment Details");
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        // Find EditText fields, TextView, and Pay button
        EditText editTextName = findViewById(R.id.editTextName);
        EditText editTextPhNo = findViewById(R.id.editTextPhNo);
        EditText editTextAddress = findViewById(R.id.editTextAddress);
        EditText editTextCity = findViewById(R.id.editTextCity);
        EditText editTextTotalAmount = findViewById(R.id.editTextTotalAmount);
        TextView orderStatusTextView = findViewById(R.id.orderStatusTextView);
        TextView billTextView = findViewById(R.id.billTextView);

        // Retrieve data from Intent (amount and bookName from CartActivity)
        String totalAmount = getIntent().getStringExtra("totalAmount");
        bookName = getIntent().getStringExtra("bookName");
        editTextTotalAmount.setText(totalAmount); // Automatically display amount

        Button payButton = findViewById(R.id.payButton);

        // Set up onClickListener for Pay button
        payButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve data from EditText fields
                String customerName = editTextName.getText().toString();
                String phNo = editTextPhNo.getText().toString();
                String address = editTextAddress.getText().toString();
                String city = editTextCity.getText().toString();

                // Retrieve gender from RadioButton
                RadioGroup radioGroupGender = findViewById(R.id.radioGroupGender);
                int selectedRadioButtonId = radioGroupGender.getCheckedRadioButtonId();
                RadioButton radioButtonGender = findViewById(selectedRadioButtonId);
                String gender = radioButtonGender.getText().toString();

                // Retrieve country from Spinner
                Spinner spinnerCountry = findViewById(R.id.spinnerCountry);
                String country = spinnerCountry.getSelectedItem().toString();

                // Perform payment processing (You can add your payment logic here)

                // Display a toast message for transaction completion
                displayTransactionCompletedMessage(customerName);

                // Display "Order Placed" message in TextView
                orderStatusTextView.setText("Order Placed! Thank you, " + customerName);

                // Display the bill details
                displayBillDetails(customerName, totalAmount, phNo, address, city, gender, country);
            }
        });
    }

    private void displayTransactionCompletedMessage(String customerName) {
        // Display a toast message for transaction completion
        Toast.makeText(this, "Transaction completed for " + customerName + ". Order placed!", Toast.LENGTH_SHORT).show();
    }

    private void displayBillDetails(String customerName, String totalAmount, String phNo, String address, String city, String gender, String country) {
        // Display the bill details in the TextView
        String billDetails = "Bill Details:\t\t\t" +
                "Customer Name: " + customerName + "\n" +
                "Book Name: " + bookName + "\t\t\t" +
                "Total Amount: " + totalAmount + "\n" +
                "Phone Number: " + phNo + "\n" +
                "Address: " + address + "\n" +
                "Gender: " + gender + "\n" +
                "City: " + city + "\t\t\t" +
                "Country: " + country;

        TextView billTextView = findViewById(R.id.billTextView);
        billTextView.setText(billDetails);
    }
}
